
def the_list(element):
    list + element = list
    if input == "fin":
        print[list]

element = input("Please enter an element to add to the list [fin = finished]:")


