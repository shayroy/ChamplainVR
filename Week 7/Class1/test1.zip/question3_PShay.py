import balance
class BankAccount(balance):
    """the bank account balance."""

    def __init__(self, balance, deposit, withdraw):
        self.balance = balance = 0
        self.deposit = deposit
        self.withdraw = withdraw

    def __init__withdraw(self):
        balance - withdraw = balance

    def __init__deposit(self):
        balance + deposit = balance



    b = BankAccount(10)
    b.deposit(25)
    b.withdraw(1)
    print("The balance of the bank account is now" + str(b.balance))
